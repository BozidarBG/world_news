<?php $__env->startSection('styles'); ?>
    <?php echo toastr_css(); ?>
    <style>

    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('admin.includes.errors', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="row">
        <!-- ============= Post Content Area Start ============= -->
    <div class="col-12 col-lg-8">
        <div class="post-content-area mb-50">

            <!-- Catagory Area -->
            <div class="world-catagory-area">
                <ul class="nav nav-tabs" id="myTab" role="tablist">
                    <li class="title"><?php echo e($article->category->title); ?></li>
                </ul>

                <div class="single-blog-content mb-20">
                    <!-- Post Meta -->
                    <div class="post-meta mt-30">
                        <h2><?php echo e($article->title); ?></h2>
                    </div>
                    <!-- Post Content -->
                    <div class="post-content">
                        <img src="<?php echo e(asset($article->photo)); ?>" alt="<?php echo e($article->title); ?>" class="mb-50">
                        <p> <?php echo $article->body; ?></p>
                        <!-- Post Meta -->
                        <div class="post-meta second-part">
                            <p><span href="#" class="post-author"><?php echo e($article->user->name); ?></span> on <span class="post-date"><?php echo e($article->updated_at->format('d.m.Y')); ?></span></p>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>
</div>

<div class="col-md-4 ">
    <form action="<?php echo e(route('articles.moderator-update', ['id'=>$article->id])); ?>" method="post" >
            <?php echo e(csrf_field()); ?>

        <div class="card mb-4 mr-4">

            <div class="card-header bg-danger ">
                <h5 class="text-white text-center"><?php echo e($article->approved ? 'Unapprove' : 'Approve'); ?></h5>
            </div>
            <div class="card text-center p-4">

                <br>

                <div class="text-center">
                    <button type="submit" name="submit" class="btn btn-info">Confirm</button>
                </div>
            </div>
        </div>
    </form>
</div>
    <!-- where --->
<div class="col-12 col-md-4">
<form action="<?php echo e(route('articles.moderator-article-position', ['id'=>$article->id])); ?>" method="post" >
    <?php echo e(csrf_field()); ?>

    <div class="card mb-4 mr-4">

        <div class="card-header bg-danger ">
            <h5 class="text-white text-center"><?php echo e($slider ? 'Remove from slider' : 'Put in Slider'); ?></h5>
        </div>
        <div class="card text-center p-4">

            <br>
            <div class="text-center">
                <button type="submit" name="submit" class="btn btn-info">Confirm</button>
            </div>
        </div>
    </div>
</form>
</div>









<?php $__env->stopSection(); ?>



<?php $__env->startSection('scripts'); ?>

    <?php echo toastr_js(); ?>
    <script>
        <?php if(Session::has('success')): ?>
            toastr.options.hideMethod = 'slideUp';
        toastr.success("<?php echo e(Session::get('success')); ?>");
        <?php endif; ?>

        <?php if(Session::has('info')): ?>
            toastr.options.hideMethod = 'slideUp';
        toastr.info("<?php echo e(Session::get('info')); ?>");
        <?php endif; ?>

        <?php if(Session::has('error')): ?>
            toastr.options.hideMethod = 'slideUp';
        toastr.error("<?php echo e(Session::get('error')); ?>");
        <?php endif; ?>
    </script>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.frontend.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>