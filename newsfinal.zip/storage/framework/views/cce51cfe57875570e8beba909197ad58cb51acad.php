<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css.toastr.css')); ?>">
    <?php echo toastr_css(); ?>
<style>


</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
        <!-- ============= Post Content Area Start ============= -->
<div class="col-12 col-lg-8">
    <div class="post-content-area mb-30">

        <!-- Catagory Area -->
        <div class="world-catagory-area">
            <ul class="nav nav-tabs" id="myTab" role="tablist">
                <li class="title"><?php echo e($article->category->title); ?></li>
            </ul>

            <div class="single-blog-content mb-20">
                <!-- Post Meta -->
                <div class="post-meta mt-30">
                    <h2><?php echo e($article->title); ?></h2>
                </div>
                <!-- Post Content -->
                <div class="post-content">
                    <img src="<?php echo e(asset($article->photo)); ?>" alt="<?php echo e($article->title); ?>" class="mb-50">
                    <p> <?php echo $article->body; ?></p>
                    <!-- Post Meta -->
                    <div class="post-meta second-part">
                        <p><span  class="post-author"><?php echo e($article->user->name); ?></span> on <span class="post-date"><?php echo e($article->showDate( true)); ?></span></p>
                    </div>
                </div>

            </div>
        </div>

    </div>
</div>



<!-- ========== Sidebar Area ========== -->
<?php echo $__env->make('layouts.frontend.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- comments ------------------------------->
<div class="row">
    <div class="col-12 col-lg-8">
        <!--comment form start --->
        <?php if(Auth::check()): ?>
        <div class="post-a-comment-area pt-4 pb-4">
            <h5>Your comment</h5>
            <!-- Contact Form -->
            <form action="<?php echo e(route('comment.store')); ?>" method="post">
                <div class="row">
                    <?php echo e(csrf_field()); ?>

                    <div class="col-12">
                        <div class="group">
                            <input type="hidden" name="name" value="<?php echo e($article->slug); ?>">
                            <textarea name="body" id="message" required></textarea>
                            <span class="highlight"></span>
                            <span class="bar"></span>
                            <label>Enter your comment</label>
                        </div>
                    </div>
                    <div class="col-12">
                        <button type="submit" class="btn world-btn">Post comment</button>
                    </div>
                </div>
            </form>
        </div>
        <?php else: ?>
        <h5>Please <a class="btn world-btn login-event" href="#login-form">login</a> or <a href="#register-form" class="btn world-btn register-event">register</a> to comment this article </h5>
        <?php endif; ?>
    </div>
    <!-- end comment form-->

    <div class="col-12 col-lg-8">
        <!-- Comment Area Start - comment then reply, if any -->
        <div class="comment_area clearfix mt-70">
            <?php if($article->comments->count() > 0): ?>

            <ol>
                <?php $__currentLoopData = $article->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!-- Single Comment Area -->
                <li class="single_comment_area">
                    <!-- Comment Content -->
                    <div class="comment-content">
                        <!-- Comment Meta -->
                        <div class="comment-meta d-flex align-items-center justify-content-between">
                            <p>
                                <span class="post-author"><?php echo e($comment->user->name); ?></span> on <span class="post-date"><?php echo e($comment->showDate($comment->created_at, true)); ?></span>
                            </p>
                            <?php if(Auth::check()): ?>
                            <a href="#" class="comment-reply btn world-btn">Reply</a>
                            <?php endif; ?>
                        </div>
                        <p><?php echo e($comment->body); ?></p>
                    </div>
                    <!--- replies start if any ----->
                    <?php if(Auth::check()): ?>
                    <div class="post-a-comment-area pt-4 pb-4 mt-3 hiddenReplyForm" id="reply<?php echo e($comment->id); ?>">
                        <h5>Reply</h5>
                        <!-- Contact Form -->
                        <form action="<?php echo e(route('reply.store')); ?>" method="post">
                            <div class="row">
                                <?php echo e(csrf_field()); ?>

                                <div class="col-12">
                                    <div class="group">
                                        <input type="hidden" name="name" value="<?php echo e($comment->id); ?>">
                                        <textarea name="body" id="message" required></textarea>
                                        <span class="highlight"></span>
                                        <span class="bar"></span>
                                        <label>Enter your reply for this comment</label>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <button type="submit" class="btn world-btn">Post reply</button>
                                </div>
                            </div>
                        </form>
                    </div>

                    <?php endif; ?>

                    <?php if($comment->replies->count()>0): ?>
                        <?php $__currentLoopData = $comment->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <ol class="children">
                        <li class="single_comment_area">
                            <!-- Reply Content -->
                            <div class="comment-content">
                                <!-- Reply Meta -->
                                <div class="comment-meta d-flex align-items-center justify-content-between">
                                    <p>
                                        <span class="post-author"><?php echo e($reply->user->name); ?></span> on <span class="post-date"><?php echo e($reply->showDate($reply->created_at, true)); ?></span>
                                    </p>
                                </div>
                                <p><?php echo e($reply->body); ?></p>
                            </div>
                        </li>
                    </ol>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>


                    <!-- reply end all --->
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ol>
            <?php else: ?>
            There are no comments for this article
            <?php endif; ?>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php echo toastr_js(); ?>
    <script src="<?php echo e(asset('js.toastr.js')); ?>"></script>
    <script>
        <?php if(Session::has('success')): ?>
            toastr.options.hideMethod = 'slideUp';
        toastr.success("<?php echo e(Session::get('success')); ?>");
        <?php endif; ?>

        <?php if(Session::has('info')): ?>
            toastr.options.hideMethod = 'slideUp';
        toastr.info("<?php echo e(Session::get('info')); ?>");
        <?php endif; ?>

        <?php if(Session::has('error')): ?>
            toastr.options.hideMethod = 'slideUp';
        toastr.error("<?php echo e(Session::get('error')); ?>");
        <?php endif; ?>
    </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>