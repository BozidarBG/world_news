<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/email.css')); ?>">
    <style>

    </style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <?php echo $__env->make('admin.includes.errors', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="card mb-3">
                <div class="card-header">
                    <h5><?php echo e($page_name); ?></h5>
                </div>
            </div>

            <div class="card">
                <div class="card-body p-2">
                    <form action="<?php echo e(route('email.store')); ?>" method="POST" class="form-horizontal">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <label for="receiver">
                                <?php if($page_name==="Reply page"): ?>
                                    Reply to:
                                <?php elseif($page_name==="Forward page"): ?>
                                    Forward to:
                                    <?php endif; ?>
                            </label>
                            <?php if($page_name==="Forward page"): ?>

                            <select name="receiver" class="form-control" name="receiver">
                                <option value="" disabled selected>Select recipient</option>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($user->hashid); ?>"><?php echo e($user->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php else: ?>
                            <input type="text" class="form-control" value="<?php echo e($email->getUsersName($email->sender)); ?>" disabled>
                            <input type="hidden" value="<?php echo e($email->getUsersHashid($email->sender)); ?>" name="receiver">
                            <?php endif; ?>
                            <input type="hidden" value="<?php echo e($email->hashid); ?>" name="previous">
                        </div>
                        <div class="form-group">
                            <label for="title">Enter the title of your message</label>
                            <input type="text" class="form-control" name="title" value="<?php echo e($page_name==="Reply page" ? "Re:" : "Fw:"); ?> <?php echo e($email->title); ?>">
                        </div>
                        <div class="form-group" >
                            <label for="body">Enter the body of your message</label>
                            <textarea name="body"  class="form-control">
                                <br>
                                <hr>
                                <p>Subject: <?php echo e($email->title); ?></p>
                                <p>From: <?php echo e($email->getUsersName($email->sender)); ?></p>
                                <p>To: <?php echo e($email->getUsersName($email->receiver)); ?></p>
                                <p>On: <?php echo e($email->showDate(true)); ?></p>
                                <p><strong>YPrevious message(s):</strong></p>
                                <?php echo $email->body; ?>


                            </textarea>
                        </div>

                        <div class="form-group">
                            <div class="text-center">
                                <button type="submit" name="send" class="btn btn-success">Send</button>
                                <button type="submit" name="save" class="btn btn-primary">Save to drafts</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>


    <script src="https://cdn.ckeditor.com/4.10.1/standard/ckeditor.js"></script>
    <script>
        CKEDITOR.replace( 'body' );
        CKEDITOR.config.removePlugins = 'image';
    </script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>