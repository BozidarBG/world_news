<?php $__env->startSection('styles'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                Edit Web Site Settings
            </div>
            <div class="card-body">
                <?php echo $__env->make('admin.includes.errors', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <form action="<?php echo e(route('settings.update')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>


                    <div class="form-group">
                        <label for="name">Website Name</label>
                        <input type="text" name="name" class="form-control" value="<?php echo e($settings->name); ?>">
                    </div>

                    <div class="form-group">
                        <label for="address">Address</label>
                        <textarea name="address" class="form-control"><?php echo e($settings->address); ?></textarea>
                    </div>

                    <div class="form-group">
                        <label for="email">Website email</label>
                        <input type="text" name="email" class="form-control" value="<?php echo e($settings->email); ?>">
                    </div>

                    <div class="form-group" >
                        <label for="about">About</label>
                        <textarea name="about" class="form-control"><?php echo $settings->about; ?></textarea>
                    </div>


                    <div class="form-group">
                        <div class="text-center">
                            <button type="submit" name="submit" class="btn btn-info">Update</button>
                        </div>
                    </div>


                </form>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script src="https://cdn.ckeditor.com/4.10.1/standard/ckeditor.js"></script>
    <script>
        CKEDITOR.replace( 'about' );
        CKEDITOR.replace( 'address' );
        CKEDITOR.config.removePlugins = 'image';
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>