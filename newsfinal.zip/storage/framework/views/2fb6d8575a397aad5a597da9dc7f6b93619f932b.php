<tr data-id="<?php echo e($hashid); ?>" <?php echo e($unread); ?>>
    <td class="email-checkbox">
        <input type="checkbox" class="checkbox">
    </td>

    <td class="email-favorite"><i class="<?php echo e($star); ?> fa-star"></i></td>

    <td class="email-name"><?php echo e($user); ?></td>

    <td class="email-subject">
        <a class="email-link" href='<?php echo e(route($route, ["hashid"=>$email->hashid])); ?>'><?php echo e($title); ?></a>
    </td>

    <td class="email-date"><?php echo e($date); ?></td>
</tr>