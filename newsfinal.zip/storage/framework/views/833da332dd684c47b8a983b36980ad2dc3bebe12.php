<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/email.css')); ?>">
    <style>

    </style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <?php echo $__env->make('admin.includes.errors', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="card mb-3">
                <div class="card-header">
                    <h5>Read email</h5>
                </div>
                <div class="col-md-4 form-group">
                    <a href="<?php echo e(route('email.reply', ['hashid'=>$email->hashid])); ?>" class="btn btn-primary btn-sm float-left"><i class="fas fa-reply"></i>&nbsp;Reply</a>
                    <a href="<?php echo e(route('email.forward', ['hashid'=>$email->hashid])); ?>" class="btn btn-primary btn-sm float-right"><i class="fas fa-share"></i>&nbsp;Forward</a>
                </div>

                <div class="card-body">
                    <h6>Subject: <?php echo e($email->title); ?></h6>
                    <h6>From: <?php echo e($email->getUsersName($email->sender)); ?></h6>
                    <h6>To: <?php echo e($email->getUsersName($email->receiver)); ?></h6>
                    <h6>On: <?php echo e($email->showDate(true)); ?></h6>
                    <div class="card mb-3">
                        <p class="card-text"><?php echo $email->body; ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>