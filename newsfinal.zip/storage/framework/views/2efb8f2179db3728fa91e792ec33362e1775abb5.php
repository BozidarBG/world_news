<?php $__env->startSection('styles'); ?>
<style>

</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
        <!-- ============= Post Content Area Start ============= -->
<div class="col-12 col-lg-8">
    <div class="post-content-area mb-50">
        <!-- Catagory Area -->
        <div class="world-catagory-area">
            <ul class="nav nav-tabs" id="myTab" role="tablist">
                <li class="title">Most important news</li>

            </ul>

            <div class="tab-content" id="myTabContent">

                <div class="tab-pane fade show active" id="world-tab-1" role="tabpanel" aria-labelledby="tab1">
                    <div class="row">
                        <!--start slajder------------------------------------------->
                        <div class="col-12 col-md-6">
                            <div class="world-catagory-slider owl-carousel wow fadeInUpBig" data-wow-delay="0.1s">
                                <?php if($fr_slider): ?>

                                <?php $__currentLoopData = $fr_slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <!-- Single Blog Post -->
                                <div class="single-blog-post">
                                    <!-- Post Thumbnail -->
                                    <div class="post-thumbnail">
                                        <img src="<?php echo e($slide->article->photo); ?>" alt="<?php echo e($slide->article->title); ?>">
                                        <!-- Catagory -->
                                        <div class="post-cta"><a href="<?php echo e(route('category',['slug'=>$slide->article->category->slug])); ?>"><?php echo e($slide->article->category->title); ?></a></div>
                                    </div>
                                    <!-- Post Content -->
                                    <div class="post-content">
                                        <a href="<?php echo e(route('show', ['category_slug'=>$slide->article->category->slug, 'article_slug'=>$slide->article->slug ])); ?>" class="headline">
                                            <h5><?php echo e($slide->article->title); ?></h5>
                                        </a>
                                        <p><?php echo e($slide->article->shortenText(10)); ?></p>
                                        <!-- Post Meta -->
                                        <div class="post-meta">
                                            <p><span class="post-author"><?php echo e($slide->article->user->name); ?></span> on <span class="post-date"><?php echo e($slide->article->showDate()); ?></span></p>
                                        </div>
                                    </div>
                                </div>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>




                            </div>
                        </div>
                        <!--end slajder------------------------------------------------------->
                        <!--pored slajdera-->
                        <div class="col-12 col-md-6">
                            <!-- Single Blog Post -->
                            <?php if($asideslider->count()>0): ?>
                                <?php $sec=0.2; ?>
                                <?php $__currentLoopData = $asideslider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="single-blog-post post-style-2 d-flex align-items-center wow fadeInUpBig" data-wow-delay="$sec.s">
                                <!-- Post Thumbnail -->
                                <div class="post-thumbnail">
                                    <img src="<?php echo e(asset($article->photo)); ?>" alt="<?php echo e($article->title); ?>" width="150px">
                                </div>
                                <!-- Post Content -->
                                <div class="post-content pt-4 pb-5">
                                    <a href="<?php echo e(route('show', ['category_slug'=>$article->category->slug, 'article_slug'=>$article->slug ])); ?>" class="headline">
                                        <h5><?php echo e($article->title); ?></h5>
                                    </a>
                                    <!-- Post Meta -->
                                    <div class="post-meta">
                                        <p><span class="post-author"><?php echo e($article->user->name); ?></span> on <span class="post-date"><?php echo e($article->showDate()); ?></span></p>
                                    </div>
                                </div>
                            </div>
                            <?php $sec+=0.1; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

                        </div>
                    </div>
                </div>
                <!--kraj pored slajdera -------------------------------->


            </div>
        </div>


    </div>
</div>

<!-- ========== Sidebar Area ========== -->
<?php echo $__env->make('layouts.frontend.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>



<!-- kategorija levo i kategorija desno ------------------------------------------------>
<div class="world-latest-articles">
    <div class="row">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-12 col-lg-6">
            <div class="title">
                <h5><?php echo e($category->title); ?></h5>
            </div>
            <?php $seconds=0.2; ?>
            <?php $__currentLoopData = $category->latestFourArticles(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <!-- Single Blog Post -->
            <div class="single-blog-post post-style-4 d-flex align-items-center single-height wow fadeInUpBig" data-wow-delay="$seconds.s">
                <!-- Post Thumbnail -->
                <div class="post-thumbnail">
                    <img src="<?php echo e($article->photo); ?>" alt="<?php echo e($article->title); ?>">
                </div>
                <!-- Post Content -->
                <div class="post-content">
                    <a href="<?php echo e(route('show', ['category_slug'=>$article->category->slug, 'article_slug'=>$article->slug ])); ?>" class="headline">
                        <h5><?php echo e($article->title); ?></h5>
                    </a>
                    <p><?php echo e($article->shortenText(10)); ?></p>
                    <!-- Post Meta -->
                    <div class="post-meta">
                        <p><span class="post-author"><?php echo e($article->user->name); ?></span> on <span class="post-date"><?php echo e($article->showDate()); ?></></p>
                    </div>
                </div>
            </div>
            <?php $seconds+=0.1; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
</div>
<!--- kraj kategorije levo i desno ------------------------------------------------------>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>