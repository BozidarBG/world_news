<?php $__env->startSection('styles'); ?>
    <style>
        .table th, .table td{
            font-size: 80%;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="row">
                        <div class="col-md-2">
                            <?php if(isset($page_name)): ?>
                                <?php echo e($page_name); ?>

                            <?php endif; ?>
                            Articles
                        </div>
                        <div class="col-md-4">
                            
                        </div>
                        <div class="col-md-6 ">
                            <form class="form-inline float-right">
                                <div class="form-group">
                                    <input type="text" class="form-control" name="title_search" placeholder="Search by title">
                                </div>&nbsp;
                                <div class="form-group">
                                    <input type="submit" name="user_search" value="Search" class="form-control btn-success">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <?php if(count($articles)): ?>
                        <table class="table table-sm table-hover table-striped">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Category</th>
                                <th>Title</th>
                                <th>Journalist</th>
                                <th>Status</th>
                                <th>Approved By</th>
                                <th>Last Change</th>
                                <th>Edit</th>
                                <th>Destroy</th>
                                <th>Restore</th>
                            </tr>
                            </thead>

                            <tbody>
                            <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($article->id); ?></td>
                                    <td><?php echo e($article->category->title); ?></td>
                                    <td><?php echo e($article->title); ?></td>
                                    <td><?php echo e($article->user->name); ?></td>
                                    <td><?php echo e($article->approved()); ?></td>
                                    <td><?php echo e($article->approvedBy()); ?></td>
                                    <td><?php echo e($article->updated_at->format('d.m.Y')); ?>

                                        <br>
                                        <?php echo e($article->updated_at->format('H:i:s')); ?></td>
                                    <?php if(Auth::user()->isJournalist()): ?>
                                        <td><a href="<?php echo e(route('articles.edit', $article->slug)); ?>" class="btn btn-info btn-xs">Edit</a></td>
                                        <td>
                                            <form method="POST"
                                                  action="<?php echo e(route('articles.kill', ['slug'=> $article->slug])); ?>" >

                                                <?php echo csrf_field(); ?>

                                                <input type="submit" class="btn btn-danger btn-xs" value="Kill" name="submit"
                                                       onclick=" return confirm('Are you sure that you want to permanently delete this article?')">
                                            </form>
                                        </td>

                                    <?php elseif(Auth::user()->isModerator()): ?>
                                        <td><a href="<?php echo e(route('articles.moderator-edit', $article->slug)); ?>"
                                               class="btn btn-info btn-xs">Edit</a>
                                        <td>
                                            <form method="POST"
                                                  action="<?php echo e(route('articles.moderator-kill', ['slug'=> $article->slug])); ?>" >

                                                <?php echo csrf_field(); ?>

                                                <input type="submit" class="btn btn-danger btn-xs" value="Kill" name="submit"
                                                       onclick=" return confirm('Are you sure that you want to permanently delete this article?')">
                                            </form>
                                        </td>
                                    <?php endif; ?>
                                    <?php if(!Auth::user()->isAdministrator()): ?>
                                        <td><a href="<?php echo e(route('articles.restore', $article->slug)); ?>"
                                               class="btn btn-success btn-xs">Restore</a></td>

                                    <?php endif; ?>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php if($articles->perPage()<$articles->total()): ?>
                            <nav class="text-center">
                                <ul class="pagination justify-content-center">
                                    <?php echo e($articles->render()); ?>

                                </ul>
                            </nav>
                        <?php endif; ?>
                    <?php else: ?>
                        <div class="card-body">
                            There are no articles for this query
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>