<?php $__env->startSection('styles'); ?>
    <style>

    </style>
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
            <!-- ============= Post Content Area Start ============= -->
    <div class="col-12 col-lg-8">
        <div class="post-content-area mb-50">
            <!-- Catagory Area -->
            <div class="world-catagory-area">
                <ul class="nav nav-tabs" id="myTab" role="tablist">
                    <li class="title"><?php echo e($category_title); ?></li>
                </ul>

                <div class="tab-content" id="myTabContent">
                <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="tab-pane fade show active" id="world-tab-1" role="tabpanel" aria-labelledby="tab1">
                        <!-- Single Blog Post -->
                        <div class="single-blog-post post-style-4 d-flex align-items-center single-height">
                            <!-- Post Thumbnail -->
                            <div class="post-thumbnail">
                                <img src="<?php echo e(asset($article->photo)); ?>" alt="<?php echo e($article->title); ?>">
                            </div>
                            <!-- Post Content -->
                            <div class="post-content">
                                <a href="<?php echo e(route('show', ['category_slug'=>$article->category->slug, 'article_slug'=>$article->slug ])); ?>" class="headline">
                                    <h5><?php echo e($article->title); ?></h5>
                                </a>
                                <p><?php echo e($article->shortenText(10)); ?></p>
                                <!-- Post Meta -->
                                <div class="post-meta">
                                    <p><span class="post-author"><?php echo e($article->user->name); ?></span> on <span class="post-date"><?php echo e($article->showDate()); ?></span></p>
                                </div>
                            </div>
                        </div>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </div>
            </div>
            <?php if($articles->perPage()<$articles->total()): ?>
                <nav class="text-center ">
                    <ul class="pagination justify-content-center mt-5">
                        <?php echo e($articles->render()); ?>

                    </ul>
                </nav>
            <?php endif; ?>
        </div>
    </div>

    <!-- ========== Sidebar Area ========== -->
    <?php echo $__env->make('layouts.frontend.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>