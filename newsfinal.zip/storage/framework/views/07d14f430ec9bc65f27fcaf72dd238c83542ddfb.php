<?php $__env->startSection('content'); ?>

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <p class="float-left">Users</p>
                        <?php if(Auth::user()->isAdministrator()): ?>
                        <a href="<?php echo e(route('users.create')); ?>" role="button" class="btn btn-sm btn-primary float-right">Create new user</a>
                        <?php endif; ?>
                    </div>
                    <?php if(count($users)): ?>
                    <div class="card-body">
                        <table class="table table-responsive table-hover">
                            <thead class="thead-dark">
                            <tr >
                                <th class="w100">Name</th>
                                <th class="w100 d-sm-none d-md-block">Email</th>
                                <th class="w100">Permission</th>
                                <?php if(Auth::user()->isAdministrator()): ?>
                                    <th class="w100">Edit</th>
                                <?php endif; ?>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($user->name); ?></td>
                                    <td class="d-sm-none d-md-block"><?php echo e($user->email); ?></td>
                                    <td><?php echo e($user->role->name); ?></td>
                                    <?php if(Auth::user()->isAdministrator()): ?>
                                        <td><a href="<?php echo e(route('users.edit', ['hashid'=>$user->hashid])); ?>" role="button" class="btn btn-primary btn-sm">Edit</a></td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>