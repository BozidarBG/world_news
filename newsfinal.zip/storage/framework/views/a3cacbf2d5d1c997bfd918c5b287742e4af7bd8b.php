<?php $__env->startSection('styles'); ?>
    <style>
        .table th, .table td{
            font-size: 80%;
        }
        .draft-header{
            background: yellow;
        }
        .unapproved-header{
            background: orange;
        }
        .approved-header{
            background: green;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header draft-header">
                    Drafts Articles
                </div>
                <div class="card-body">
                    <?php if(count($drafts)): ?>
                        <table class="table table-sm table-hover table-striped">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Category</th>
                                <th>Title</th>
                                <th>Status</th>
                                <th>Approved By</th>
                                <th>Last Change</th>
                                <th>Edit</th>
                                <th>Trash</th>
                            </tr>
                            </thead>

                            <tbody>
                            <?php $__currentLoopData = $drafts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $draft): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($draft->id); ?></td>
                                    <td><?php echo e($draft->category->title); ?></td>
                                    <td><?php echo e($draft->title); ?></td>
                                    <td><?php echo e($draft->approved()); ?></td>
                                    <td><?php echo e($draft->approvedBy()); ?></td>
                                    <td><?php echo e($draft->updated_at->format('d.m.Y')); ?>

                                        <br>
                                        <?php echo e($draft->updated_at->format('H:i:s')); ?>

                                    </td>
                                    <td><a href="<?php echo e(route('articles.edit', $draft->slug)); ?>" class="btn btn-info btn-sm">Edit</a></td>
                                    <td>
                                        <form method="POST"
                                              action="<?php echo e(route('articles.destroy', ['slug'=> $draft->slug])); ?>" >

                                            <?php echo csrf_field(); ?>

                                            <input type="submit" class="btn btn-danger btn-sm" value="Del" name="submit"
                                                   onclick=" return confirm('Are you sure that you want to send this article to trash?')">
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                    <?php else: ?>
                        <div class="card-body">
                            There are no articles for this query
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="row mt-2">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header bg-warning">
                    Unapproved Articles
                </div>
                <div class="card-body">
                    <?php if(count($unapproved_articles)): ?>
                        <table class="table table-sm table-hover table-striped">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Category</th>
                                <th>Title</th>
                                <th>Last Change</th>
                                <th>Edit</th>
                                <th>Trash</th>
                            </tr>
                            </thead>

                            <tbody>
                            <?php $__currentLoopData = $unapproved_articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($article->id); ?></td>
                                    <td><?php echo e($article->category->title); ?></td>
                                    <td><?php echo e($article->title); ?></td>
                                    <td><?php echo e($article->updated_at->format('d.m.Y')); ?>

                                        <br>
                                        <?php echo e($article->updated_at->format('H:i:s')); ?>

                                    </td>
                                    <td><a href="<?php echo e(route('articles.edit', $article->slug)); ?>" class="btn btn-info btn-sm">Edit</a></td>
                                    <td>
                                        <form method="POST"
                                              action="<?php echo e(route('articles.destroy', ['slug'=> $article->slug])); ?>" >

                                            <?php echo csrf_field(); ?>

                                            <input type="submit" class="btn btn-danger btn-sm" value="Del" name="submit"
                                                   onclick=" return confirm('Are you sure that you want to send this article to trash?')">
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                    <?php else: ?>
                        <div class="card-body">
                            There are no articles for this query
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="row mt-2">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header bg-success">
                    Approved Articles
                </div>
                <div class="card-body">
                    <?php if(count($approved_articles)): ?>
                        <table class="table table-sm table-hover table-striped">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Category</th>
                                <th>Title</th>
                                <th>Approved by</th>
                                <th>Last Change</th>
                            </tr>
                            </thead>

                            <tbody>
                            <?php $__currentLoopData = $approved_articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($article->id); ?></td>
                                    <td><?php echo e($article->category->title); ?></td>
                                    <td><?php echo e($article->title); ?></td>
                                    <td><?php echo e($article->approvedBy()); ?></td>
                                    <td><?php echo e($article->updated_at->format('d.m.Y')); ?>

                                        <br>
                                        <?php echo e($article->updated_at->format('H:i:s')); ?>

                                    </td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php if($approved_articles->perPage()<$approved_articles->total()): ?>
                            <nav class="text-center">
                                <ul class="pagination justify-content-center">
                                    <?php echo e($approved_articles->render()); ?>

                                </ul>
                            </nav>
                        <?php endif; ?>

                    <?php else: ?>
                        <div class="card-body">
                            There are no articles for this query
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>