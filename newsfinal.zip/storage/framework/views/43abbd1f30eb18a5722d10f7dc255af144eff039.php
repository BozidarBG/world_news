<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/email.css')); ?>">
    <style>

    </style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
    $subject="";
    $body="";
    $to="";
    if(isset($draft_email)){

        $subject=$draft_email->title;
        $body=$draft_email->body;
        //$to=$draft_email->
    }
    ?>
    <div class="row">
        <div class="col-md-12">
            <?php echo $__env->make('admin.includes.errors', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="card">
                <div class="card-header">
                    <h5>Create new email</h5>
                </div>
                <div class="card-body p-2">
                    <form action="<?php echo e(route('email.store')); ?>" method="POST" class="form-horizontal">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <label for="receiver">Select receiver</label>
                            <select name="receiver" class="form-control" name="receiver">
                                <option value="" disabled selected>Select recipient</option>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($user->hashid); ?>"><?php echo e($user->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="title">Enter the title of your message</label>
                            <input type="text" class="form-control" name="title" placeholder="Enter subject" value="<?php echo e($subject); ?>">
                        </div>
                        <div class="form-group" >
                            <label for="body">Enter the body of your message</label>
                            <textarea name="body"  class="form-control"><?php echo $body; ?></textarea>
                        </div>

                        <div class="form-group">
                            <div class="text-center">
                                <button type="submit" name="send" class="btn btn-success">Send</button>
                                <button type="submit" name="save" class="btn btn-primary">Save to drafts</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>


    <script src="https://cdn.ckeditor.com/4.10.1/standard/ckeditor.js"></script>
    <script>
        CKEDITOR.replace( 'body' );
        CKEDITOR.config.removePlugins = 'image';
    </script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>