<div class="hero-area">

    <!-- Hero Slides Area -->
    <div class="hero-slides owl-carousel">
        <!-- Single Slide -->

        <div class="single-hero-slide bg-img background-overlay" style="background-image: url('<?php echo asset('img/blog-img/bg1.jpg'); ?>');"></div>
        <!-- Single Slide -->
        <div class="single-hero-slide bg-img background-overlay" style="background-image: url('<?php echo asset('img/blog-img/bg2.jpg'); ?>');"></div>
    </div>

    <!-- Hero Post Slide -->
    <div class="hero-post-area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="hero-post-slide">

                        <?php if($fr_slider): ?>
                            <?php $i=1; ?>
                            <?php $__currentLoopData = $fr_slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!-- Single Slide -->
                            <div class="single-slide d-flex align-items-center">
                                <div class="post-number">
                                    <p><?php echo e($i); ?></p>
                                </div>
                                <div class="post-title">
                                    <a href="<?php echo e(route('show', ['category_slug'=>$slide->article->category->slug, 'article_slug'=>$slide->article->slug ])); ?>"><?php echo e($slide->article->title); ?></a>
                                </div>
                            </div>
                            <?php $i++; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>