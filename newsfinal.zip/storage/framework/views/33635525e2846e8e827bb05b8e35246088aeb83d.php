<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>



    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    Create New Article
                </div>

                <div class="card-body">
                    <?php echo $__env->make('admin.includes.errors', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <form action="<?php echo e(route('articles.store')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <label for="title">Title</label>
                            <input type="text" name="title" class="form-control" value="<?php echo e(old('title')); ?>">
                        </div>

                        <div class="form-group">
                            <label for="photo">Photo</label>
                            <input type="file" name="photo" class="form-control">
                        </div>

                        <div class="form-group">
                            <label for="category">Select a Category</label>
                            <select id="category" name="category"   class="form-control" value="<?php echo e(old('category')); ?>">
                                <option value="">Please select</option>
                                <?php if(count($categories)): ?>
                                    <?php $__currentLoopData = $categories->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option  value="<?php echo e($category->id); ?>" <?php echo e(old('category') == $category->id ? 'selected' : ''); ?>><?php echo e($category->title); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <option>error</option>
                                <?php endif; ?>
                            </select>
                        </div>

                        <div class="form-group" >
                            <label for="body">Content</label>
                            <textarea  name="body"  class="form-control"><?php echo old('body'); ?></textarea>
                        </div>


                        <div class="form-group">
                            <div class="text-center">
                                <button type="submit" name="send" class="btn btn-success">Send for approval</button>
                                &nbsp; &nbsp;or&nbsp; &nbsp;
                                <button type="submit" name="save" class="btn btn-warning">Save to drafts</button>
                            </div>
                        </div>


                    </form>
                </div>


            </div>
        </div>
    </div>

    <?php $__env->stopSection(); ?>



<?php $__env->startSection('scripts'); ?>

    <script src="https://cdn.ckeditor.com/4.10.1/standard/ckeditor.js"></script>
    <script>
        CKEDITOR.replace( 'body' );
        CKEDITOR.config.removePlugins = 'image';
    </script>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>