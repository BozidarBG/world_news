@extends('layouts.admin.adminlayout')

@section('content')
    <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="#">Dashboard</a>
        </li>
        <li class="breadcrumb-item">Overview</li>
    </ol>
    @endsection